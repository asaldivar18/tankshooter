// class GameController {
//     constructor() {
//         this.canvas = document.createElement('canvas');
//         this.canvas.id = "gamecanvas";
//         this.canvas.width = screen.width * .5
//         this.canvas.height = screen.height * .5
//         this.canvas.style.border = "1px solid"
//         document.getElementById("gamesection").appendChild(this.canvas)
//         this.createPlayer();
//         this.displayTanks()
//     }
//     createPlayer() {
//         this.opponentTank = new Tank(30, 20, false);
//         this.playerTank = new Tank(30, screen.height - screen.height * .0625 - 20, true);
//     }
//     displayTanks() {
//         this.playerTank.show(this.canvas.getContext("2d"));
//         var ctx = this.canvas.getContext("2d");
//         //ctx.rect(20, 20, 150, 100);
//         //ctx.stroke();

//     }

// }
$(function() {
    // Model model = new Model();
    // View view = new View()
    // Controller cunt = new Controller()
    $("#game").hide();
    //var cont = new GameController();
    //var ctx = document.getElementById("gamecanvas").getContext("2d")


})